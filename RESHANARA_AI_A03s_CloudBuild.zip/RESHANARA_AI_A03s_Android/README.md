# RESHANARA AI — Android project for Samsung Galaxy A03s

This is an Android Studio project that packages the existing `reshanara_ai.html` app inside a native Android WebView shell.

## Build an installable APK

1. Install **Android Studio** on a Windows, macOS, or Linux computer.
2. Extract this ZIP and open the `RESHANARA_AI_A03s_Android` folder in Android Studio.
3. Allow Gradle sync and install Android SDK Platform 35 if Android Studio asks.
4. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. When the build finishes, choose **locate**. The APK is at `app/build/outputs/apk/debug/app-debug.apk`.
6. Transfer `app-debug.apk` to the Galaxy A03s, open it, and allow installation from that file source if Android asks.

## What works in this package

- App icon/launcher entry and full-screen app shell
- Existing RESHANARA AI web interface bundled locally, so the interface opens without a network connection
- Browser local storage for chat history/settings
- Online backend connection field already present in the app's AI Connection settings
- Android file picker integration for file inputs

## Important limitations

- This ZIP is Android source code, **not a prebuilt APK**. It has not been compiled or tested on a physical A03s in this environment because Android SDK/Gradle build tools are not installed here.
- The existing chat interface uses demo replies until you connect your own compatible backend. This package does not include a real on-device language model or fully offline generative AI.
- Voice input/output depends on WebView/device speech service support and installed language voices.
- For a secure online AI service, use your own HTTPS backend. Never put a private API key in the app.

## Device target

- Application ID: `com.reshanara.ai`
- Minimum Android: 6.0 (API 23)
- Target SDK: 35
- Version: 1.0
- Intended test device: Samsung Galaxy A03s, 3 GB RAM / 32 GB storage
